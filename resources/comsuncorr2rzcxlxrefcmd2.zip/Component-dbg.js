sap.ui.define(['sap/suite/ui/generic/template/lib/AppComponent'], function(AppComponent) {
    return AppComponent.extend("com.suncor.r2r.zcxlxrefcmd2.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
